
# Student Record Management System

A simple web-based project using HTML, CSS, JavaScript, C# scripting, and SQL Server (Azure SQL).

## Features
- Add and display student records
- Simple frontend and backend integration
- Azure SQL ready backend

## Tech Stack
- Frontend: HTML5, CSS3, JavaScript
- Backend: C# scripting
- Database: SQL Server (Azure SQL)
- Tools: Visual Studio, Git
